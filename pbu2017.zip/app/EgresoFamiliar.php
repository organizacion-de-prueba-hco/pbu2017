<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EgresoFamiliar extends Model
{
    protected $table='egreso_familiars';
    protected $fillable=[
    'user_id',
    'a',
    'b',
    'c',
    'd',
    'e',
    'f',
    'g',
    'h',
    'i',
    'j',
    'k',
    'l',
    'm',
    'n'

    ];

    public function user(){
        return $this->belongsto('App\User');
    }
    
}
