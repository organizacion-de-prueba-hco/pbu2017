@extends('master.servicioSocial')
@section('activacion')
	<?php  
		$a='';$b='';$c='';$c1='';$c2='';$c3='';$c4='';$d='open active';$d1='active';$d2='';$d3='';$d4='';$e='';
	?>
@endsection
@section('title','Ficha Socio Económica')
@section('estilos')
@endsection
@section('ruta')
<ul class="breadcrumb">
	<i class="ace-icon fa fa-hospital-o"></i>	
	<li class="active">Visita Domiciliaria</li>
	<li class="active">Estudiante</li>
</ul>
@endsection
@section('contenido')
	<h1>Hola Mundo d1!</h1>
@endsection
@section('script')
@endsection