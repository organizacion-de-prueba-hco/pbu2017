@extends('master.servicioSocial')
@section('activacion')
	<?php  
		$a='';$b='';$c='';$c1='';$c2='';$c3='';$c4='';$d='open active';$d1='';$d2='';$d3='active';$d4='';$e='';
	?>
@endsection
@section('titulo','Ficha Socio Económica')
@section('estilos')
@endsection
@section('ruta')
<ul class="breadcrumb">
	<i class="ace-icon fa fa-hospital-o"></i>	
	<li class="active">Visita Domiciliaria</li>
	<li class="active">Personal No Docente</li>
</ul>
@endsection
@section('contenido')
	<h1>Hola Mundo d3!</h1>
@endsection
@section('script')
@endsection