@extends('master.servicioSocial')
@section('activacion')
	<?php  
		$a=''; $b='';$c='open active';$c1=''; $c2=''; $c3=''; $c4='active';$d='';$d1='';$d2='';$d3=''; $d4='';$e='';
	?>
@endsection
@section('title','Ficha Socio Económica')
@section('estilos')
@endsection
@section('ruta')
<ul class="breadcrumb">
	<i class="ace-icon fa fa-home"></i>	
	<li class="active">Visita Domiciliaria</li>
	<li class="active">Personal Docente</li>
</ul>
@endsection
@section('contenido')
	<h1>Hola Mundo c4!</h1>
@endsection
@section('script')
@endsection