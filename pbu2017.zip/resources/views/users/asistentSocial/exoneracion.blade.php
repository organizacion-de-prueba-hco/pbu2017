@extends('master.servicioSocial')
@section('activacion')
	<?php  
		$a=''; $b='';$c=''; $c1='';$c2='';$c3='';$c4='';$d=''; $d1=''; $d2=''; $d3=''; $d4='';$e='active';
	?>
@endsection
@section('title','Ficha Socio Económica')
@section('estilos')
@endsection
@section('ruta')
<ul class="breadcrumb">
	<i class="ace-icon fa fa-medkit"></i>	
	<li class="active">Exoneración de pago para atención en el centro médico UNHEVAL</li>
</ul>
@endsection
@section('contenido')
	<h1>Hola Mundo!</h1>
@endsection
@section('script')
@endsection